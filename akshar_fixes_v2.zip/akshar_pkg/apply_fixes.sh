#!/bin/bash
# Run from your project root: bash apply_fixes.sh
set -e
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

copy_file() {
  local src="$SCRIPT_DIR/fixed_lib/$1"
  local dst="lib/$1"
  mkdir -p "$(dirname "$dst")"
  cp "$src" "$dst"
  echo "  ✓ lib/$1"
}

echo "Applying fixes to $(pwd)..."

copy_file "app_theme.dart"
copy_file "screens/home_screen.dart"
copy_file "screens/draw_screen.dart"
copy_file "screens/camera_screen.dart"
copy_file "screens/image_screen.dart"
copy_file "widgets/mode_selector.dart"
copy_file "widgets/type_toggle.dart"
copy_file "widgets/results_panel.dart"
copy_file "widgets/drawing_canvas.dart"

# Remove the stray akshar/ folder if it exists
rm -rf akshar/

echo ""
echo "Done! Now run:"
echo "  git add lib/"
echo "  git commit -m 'fix: English-only UI, matte colors, remove Hindi and gradients'"
echo "  git push"
